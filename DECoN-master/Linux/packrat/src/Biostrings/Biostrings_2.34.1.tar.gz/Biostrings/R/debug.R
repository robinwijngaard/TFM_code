###

debug_utils <- function()
    invisible(.Call2("debug_utils", PACKAGE="Biostrings"))

debug_RoSeqs_utils <- function()
    invisible(.Call2("debug_RoSeqs_utils", PACKAGE="Biostrings"))

debug_XString_class <- function()
    invisible(.Call2("debug_XString_class", PACKAGE="Biostrings"))

debug_XStringSet_class <- function()
    invisible(.Call2("debug_XStringSet_class", PACKAGE="Biostrings"))

debug_XStringSet_io <- function()
    invisible(.Call2("debug_XStringSet_io", PACKAGE="Biostrings"))

debug_SparseList_utils <- function()
    invisible(.Call2("debug_SparseList_utils", PACKAGE="Biostrings"))

debug_match_reporting <- function()
    invisible(.Call2("debug_match_reporting", PACKAGE="Biostrings"))

debug_MIndex_class <- function()
    invisible(.Call2("debug_MIndex_class", PACKAGE="Biostrings"))

debug_lowlevel_matching <- function()
    invisible(.Call2("debug_lowlevel_matching", PACKAGE="Biostrings"))

debug_match_pattern_boyermoore <- function()
    invisible(.Call2("debug_match_pattern_boyermoore", PACKAGE="Biostrings"))

debug_match_pattern_shiftor <- function()
    invisible(.Call2("debug_match_pattern_shiftor", PACKAGE="Biostrings"))

debug_match_pattern_indels <- function()
    invisible(.Call2("debug_match_pattern_indels", PACKAGE="Biostrings"))

debug_match_pattern <- function()
    invisible(.Call2("debug_match_pattern", PACKAGE="Biostrings"))

debug_match_BOC <- function()
    invisible(.Call2("debug_match_BOC", PACKAGE="Biostrings"))

debug_match_BOC2 <- function()
    invisible(.Call2("debug_match_BOC2", PACKAGE="Biostrings"))

debug_find_palindromes <- function()
    invisible(.Call2("debug_find_palindromes", PACKAGE="Biostrings"))

debug_BitMatrix <- function()
    invisible(.Call2("debug_BitMatrix", PACKAGE="Biostrings"))

debug_PreprocessedTB_class <- function()
    invisible(.Call2("debug_PreprocessedTB_class", PACKAGE="Biostrings"))

debug_match_pdict_utils <- function()
    invisible(.Call2("debug_match_pdict_utils", PACKAGE="Biostrings"))

debug_match_pdict_Twobit <- function()
    invisible(.Call2("debug_match_pdict_Twobit", PACKAGE="Biostrings"))

debug_match_pdict_ACtree2 <- function()
    invisible(.Call2("debug_match_pdict_ACtree2", PACKAGE="Biostrings"))

debug_match_pdict <- function()
    invisible(.Call2("debug_match_pdict", PACKAGE="Biostrings"))

